public class Moto extends Vehiculo {

    public Moto(String marca, Piloto piloto, double velocidadBase) {
        super("Moto", piloto, velocidadBase);
        this.marca = marca;
    }
}
