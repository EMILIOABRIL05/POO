public class Automovil extends Vehiculo {

    public Automovil(String tipo, Piloto piloto, double velocidadBase) {
        super(tipo, piloto, velocidadBase);
    }
}
