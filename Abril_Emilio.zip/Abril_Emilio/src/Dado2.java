/*public class Dado2 {
    protected  int dado2;

    public Dado2(int dado2) {
        this.dado2 = dado2;
    }

    public double getDado2() {
        return dado2;
    }

    public void setDado2(int dado2) {
        this.dado2 = dado2;
    }
}
