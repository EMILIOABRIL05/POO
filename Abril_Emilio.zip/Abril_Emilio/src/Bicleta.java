public class Bicleta extends Vehiculo {

    public Bicleta(String tipo, Piloto piloto, double velocidadBase) {
        super("Bicileta", piloto, velocidadBase);
    }

}
